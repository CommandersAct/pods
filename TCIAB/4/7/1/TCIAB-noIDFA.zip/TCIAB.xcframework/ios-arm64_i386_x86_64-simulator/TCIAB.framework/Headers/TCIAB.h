//
//  TCIAB.h
//  TCIAB
//
//  Created by JeanJulien on 17/05/2019.
//  Copyright © 2019 TagCommander. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TCIAB.
FOUNDATION_EXPORT double TCIABVersionNumber;

//! Project version string for TCIAB.
FOUNDATION_EXPORT const unsigned char TCIABVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TCIAB/PublicHeader.h>
