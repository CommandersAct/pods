#!/bin/sh

#  copy_framework.sh
#  TCSegment
#
#  Created by JeanJulien on 07/11/2016.
#  Copyright © 2016 TagCommander. All rights reserved.

TARGET_FOLDER="${BUILD_DIR}/${CONFIGURATION}-${PLATFORM_NAME}"

TOP_IOS_FOLDER="${PROJECT_DIR}/.."
TAG_TCDEMO_PROJECT_FOLDER="${TOP_IOS_FOLDER}/../../../Tag-Demo/iOS/TCDemo/"

rm -Rf "${TAG_TCDEMO_PROJECT_FOLDER}/TCPartners.framework"
cp -R "${TARGET_FOLDER}/TCPartners.framework" "${TAG_TCDEMO_PROJECT_FOLDER}"
