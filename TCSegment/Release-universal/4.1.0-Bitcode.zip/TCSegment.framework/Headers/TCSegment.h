//
//  TCSegment.h
//  TCSegment
//
//  Created by JeanJulien on 02/11/2016.
//  Copyright © 2016 TagCommander. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TCSegment.
FOUNDATION_EXPORT double TCSegmentVersionNumber;

//! Project version string for TCSegment.
FOUNDATION_EXPORT const unsigned char TCSegmentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TCSegment/PublicHeader.h>

#import <TCSegment/TCsegmentation.h>
#import <TCSegment/TCsegmentConstants.h>
#import <TCSegment/SegmentGenerated.h>
