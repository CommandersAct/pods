//
//  TCPartner_Mediametrie.h
//  TCSDK
//
//  Created by JeanJulien on 03/07/2018.
//  Copyright © 2018 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TCCore/TCEventListener.h>
#import <TCCore/TCEventSender.h>
#import <TCCore/TCMacros.h>
#import <TCCore/TCSingleton.h>

@interface TCPartner_Mediametrie : TCSingleton<ITCEventListenerDelegate, ITCEventSenderDelegate>

SINGLETON_CLASS_H(TCPartner_Mediametrie)

//- (void) setPartnerID;
- (void) startSession;
- (void) stopSession;

@property (nonatomic, assign) unsigned long long partnerID;
@property (nonatomic, retain) TCEventSender *senderDelegate;
@property (nonatomic, retain) TCEventListener *listenerDelegate;

@end
