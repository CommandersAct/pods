//
//  TCPrivacyCenterViewController.h
//  TCPrivacy
//
//  Created by JeanJulien on 26/10/2018.
//  Copyright © 2018 TagCommander. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TCPrivacyCenterViewController.h"

@interface TCIABPrivacyCenterViewController : TCPrivacyCenterViewController

@end
