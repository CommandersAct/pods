//
//  TCIABPrivacyCenterViewController.h
//  TCPrivacy
//
//  Created by JeanJulien on 20/12/2019.
//  Copyright © 2019 TagCommander. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TCPopUpContentView;
@class TCPurposeContentView;
@class TCVendorContentView;
@class TCPrivacyConfiguration;

NS_ASSUME_NONNULL_BEGIN

@interface TCIABPrivacyCenterViewController : UIViewController<UIScrollViewDelegate, UIWebViewDelegate>

//- (void) parseCustomisation: (NSDictionary *) custo;
- (UILabel *) createLabel: (int) type withText: (NSString *) text;
- (UISwitch *) createSwitchBtn: (int) ID forPrefix: (NSString *) prefix;
- (UIView *) createStackView: (int) ID;

- (IBAction) displayPurposeScreen: (id) sender;
- (IBAction) displayVendorList: (id) sender;
- (IBAction) displayVendorDetail: (id) sender;
- (IBAction) displayPurposeDetail: (id) sender;

- (void) attachFormattedConstraint: (NSString *) constraint toView: (UIView *) view;
- (void) attachConstraint: (NSString *) constraint toView: (UIView *) view;

@property (nonatomic, retain) NSDictionary *JSONDictionary;
@property (nonatomic, retain) NSMutableDictionary *metrics;

@property (nonatomic, retain) UIScrollView *scrollView;

@property (nonatomic, retain) UIView *currentContentView;
@property (nonatomic, retain) TCPurposeContentView *purposeContentView;
@property (nonatomic, retain) TCVendorContentView *vendorContentView;
@property (nonatomic, retain) TCPopUpContentView *popupContentView;

@property (nonatomic, retain) UIButton *vendorBtn;
@property (nonatomic, retain) UIButton *purposeBtn;

@property (nonatomic, retain) UISwitch *globalConsent;

@property (nonatomic, retain) NSMutableDictionary *viewsDictionary;

@property (nonatomic, retain) NSMutableArray *purposeUIObjects;
@property (nonatomic, retain) NSMutableArray *vendorUIObjects;

@property (nonatomic, retain) NSMutableDictionary *categoryLinks;
@property (nonatomic, retain) NSDictionary *savedConsent;

@property (nonatomic, retain) NSMutableArray *privacyButtons;
@property (nonatomic, retain) NSMutableArray *privacyUrls;

@property (nonatomic, retain) TCPrivacyConfiguration *configuration;

@property (nonatomic, assign) int numberOfViews;

@end

NS_ASSUME_NONNULL_END
