//
//  ETCPrivacyBehaviour.h
//  TCSDK
//
//  Created by jeanjulien on 11/05/2021.
//  Copyright © 2021 TagCommander. All rights reserved.
//

#ifndef ETCPrivacyBehaviour_h
#define ETCPrivacyBehaviour_h

typedef enum ETCPrivacyBehaviour
{
    PB_DEFAULT_BEHAVIOUR,
    PB_ALWAYS_ENABLED,
    PB_DISABLED_BY_DEFAULT
} ETCPrivacyBehaviour;

#endif /* ETCPrivacyBehaviour_h */
