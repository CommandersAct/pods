//
// Created by JeanJulien on 23/12/2016.
// Copyright (c) 2016 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TCBeaconConstants : NSObject

#pragma mark misc
extern char *const kTCBeaconsOperationQueueName;
extern unsigned long long kTCBeaconTimeoutDuration;

#pragma mark Beacon CBUUID
extern NSString *const kTCEddystoneServiceID;
extern NSString *const kTCAltBeaconServiceID;
extern NSString *const kTCiBeaconServiceID;

#pragma mark Frame type
extern const uint8_t kTCEddystoneFrameTypeID_UUID;
extern const uint8_t kTCEddystoneFrameTypeID_URL;
extern const uint8_t kTCEddystoneFrameTypeID_Telemetry;

extern NSString *const kTCEddystoneFrameType_Unknown;
extern NSString *const kTCEddystoneFrameType_UUID;
extern NSString *const kTCEddystoneFrameType_URL;
extern NSString *const kTCEddystoneFrameType_Telemetry;
extern NSString *const kTCiBeaconFrame;

#pragma mark Notifications
extern NSString *const kTCNotification_BeaconFound;
extern NSString *const kTCNotification_BeaconUpdate;
extern NSString *const kTCNotification_BeaconLost;

#pragma mark Notification keys
extern NSString *const kTCUserInfo_FrameType;
extern NSString *const kTCUserInfo_BeaconObject;

@end
