//
// Created by JeanJulien on 04/01/2017.
// Copyright (c) 2017 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TCBaseBeacon.h"

@interface TCEddyStoneTLM : TCBaseBeacon

typedef struct __attribute__((packed))
{
    uint8_t frameType;
    uint8_t version;
    int batteryVoltage;
    float temperature;
    unsigned long advertisingPDU;
    unsigned long timeSinceReboot;
} TCEddystoneTLMPlain_FrameFields;

typedef struct __attribute__((packed))
{
    uint8_t frameType;
    uint8_t version;
    uint8_t encryptedTLMData[12];
    int16_t salt;
    int16_t messageIntegrityCheck;
} TCEddystoneTLMEncrypted_FrameFields;

- (id) initWithData: (NSDictionary *) data RSSI: (NSNumber *) RSSI andPeripheral: (CBPeripheral *) peripheral;

@property (nonatomic, assign) int version;
@property (nonatomic, assign) TCEddystoneTLMPlain_FrameFields plainFrame;
@property (nonatomic, assign) TCEddystoneTLMEncrypted_FrameFields encryptedFrame;

@end
