//
// Created by JeanJulien on 02/01/2017.
// Copyright (c) 2017 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TCBaseBeacon.h"

@interface TCEddyStoneID : TCBaseBeacon

// Note that for these Eddystone structures, the endianness of the individual fields is big-endian,
// so you'll want to translate back to host format when necessary.
// Note that in the Eddystone spec, the beaconID (UID) is divided into 2 fields, a 10 byte namespace
// and a 6 byte instance id. However, since we ALWAYS use these in combination as a 16 byte
// beaconID, we'll have our structure here reflect that.
typedef struct __attribute__((packed))
{
    uint8_t frameType;
    int8_t txPower;
    uint8_t beaconID[16];
} TCEddystoneUIDFrameFields;

@property (nonatomic, retain) NSString *UUID;
@property (nonatomic, retain) NSString *namespace;
@property (nonatomic, retain) NSString *instance;
@property (nonatomic, assign) int *RFU1;
@property (nonatomic, assign) int *RFU2;

- (id) initWithData: (NSDictionary *) data RSSI: (NSNumber *) RSSI andPeripheral: (CBPeripheral *) peripheral;

@end
