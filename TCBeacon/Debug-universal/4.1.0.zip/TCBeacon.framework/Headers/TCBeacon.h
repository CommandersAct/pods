//
//  TCBeacon.h
//  TCBeacon
//
//  Created by JeanJulien on 22/12/2016.
//  Copyright © 2016 TagCommander. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TCBeacon.
FOUNDATION_EXPORT double TCBeaconVersionNumber;

//! Project version string for TCBeacon.
FOUNDATION_EXPORT const unsigned char TCBeaconVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TCBeacon/PublicHeader.h>

#import <TCBeacon/BeaconGenerated.h>
#import <TCBeacon/TCBeacons.h>
#import <TCBeacon/TCBeaconConstants.h>
#import <TCBeacon/TCBaseBeacon.h>
#import <TCBeacon/TCEddyStoneID.h>
#import <TCBeacon/TCEddyStoneURL.h>
#import <TCBeacon/TCEddyStoneTLM.h>
#import <TCBeacon/TCiBeacon.h>
