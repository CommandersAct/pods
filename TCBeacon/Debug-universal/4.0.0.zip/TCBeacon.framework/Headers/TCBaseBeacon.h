//
// Created by JeanJulien on 02/01/2017.
// Copyright (c) 2017 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface TCBaseBeacon : NSObject

- (void) parseBaseData: (NSDictionary *) data andPeripheral: (CBPeripheral *) peripheral;
- (void) update: (NSNumber *) RSSI;

@property (nonatomic, assign) unsigned long long timestamp;
@property (nonatomic, retain) NSString *MACAdress;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSUUID *peripheralID;
@property (nonatomic, assign) int txPower;
@property (nonatomic, assign) int RSSI;

@end
