//
// Created by JeanJulien on 02/01/2017.
// Copyright (c) 2017 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "TCBaseBeacon.h"

@interface TCiBeacon : TCBaseBeacon

- (id) initWithCLBeacon: (CLBeacon *) beacon;

@property (nonatomic, retain) NSString *UUID;

- (void)updateWithCLBeacon:(CLBeacon *)beacon;

@property (nonatomic, retain) NSString *major;
@property (nonatomic, retain) NSString *minor;
@property (nonatomic, assign) CLProximity proximity;
@property (nonatomic, assign) CLLocationAccuracy accuracy;

@end
