//
// Created by JeanJulien on 23/12/2016.
// Copyright (c) 2016 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TCCore/TCSingleton.h>
#import <TCCore/TCMacros.h>

@class TCBeaconScanner;

@interface TCBeacons : TCSingleton

SINGLETON_CLASS_H(TCBeacons)

- (void) startWithBeaconType: (NSString *) type andID: (NSString *) id;

@property (nonatomic, retain) TCBeaconScanner *scanner;

@property (nonatomic, assign) int SiteID;
@property (nonatomic, retain) NSString *UUID;
@property (nonatomic, retain) NSString *baseURL;

@property (nonatomic, assign) NSTimeInterval onLostTimeout;

@end
