//
// Created by JeanJulien on 02/01/2017.
// Copyright (c) 2017 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TCBaseBeacon.h"

@interface TCEddyStoneURL : TCBaseBeacon

typedef struct __attribute__((packed))
{
    uint8_t frameType;
    int8_t  txPower;
    int8_t URLScheme;
    uint8_t encodedURL[16];
    int8_t URLExpansion;
} TCEddystoneURLFrameFields;

- (id) initWithData: (NSDictionary *) data RSSI: (NSNumber *) RSSI andPeripheral: (CBPeripheral *) peripheral;

@property (nonatomic, retain) NSString *URLExpansion;
@property (nonatomic, retain) NSString *variantURL;
@property (nonatomic, retain) NSString *URLScheme;

typedef enum
{
    eUS_Httpwww = 0,
    eUS_Httpswww = 1,
    eUS_Http = 2,
    eUS_Https = 3
} eURLScheme;

typedef enum
{
    eUE_Slash_com = 0,
    eUE_Slash_org = 1,
    eUE_Slash_edu = 2,
    eUE_Slash_net = 3,
    eUE_Slash_info = 4,
    eUE_Slash_biz = 5,
    eUE_Slash_gov = 6,
    eUE_com = 7,
    eUE_org = 8,
    eUE_edu = 9,
    eUE_net = 10,
    eUE_info = 11,
    eUE_biz = 12,
    eUE_gov = 13,
    eUE_unuzed = 14

} eURLExpansion;

@end
